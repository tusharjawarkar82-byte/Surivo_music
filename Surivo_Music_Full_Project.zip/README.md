# Surivo Music

Android music player with:
- Online streaming
- Downloads only when `downloadAllowed` is true
- Offline playback of downloaded files
- Favorites
- Search
- Background playback
- No advertising SDK
- No account/sign-in required by the app

## Important
The app intentionally does NOT bypass DRM, paywalls, subscriptions, or copyright restrictions.

For a downloadable song, the catalog must explicitly state that downloading is permitted. Put the direct MP3 URL in `downloadUrl` and set `downloadAllowed` to `true`.

For streaming-only songs:
- keep `downloadAllowed` false
- leave `downloadUrl` empty

## Run
1. Install Flutter.
2. Run `flutter pub get`.
3. Run `flutter run`.
4. Build APK with `flutter build apk --release`.

The included catalog is a safe template, not a real music source. Replace the example URL with your own/authorized/royalty-free catalog.
