import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:audio_service/audio_service.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Song {
  final String id, title, artist, audioUrl, coverUrl, downloadUrl, license;
  final bool downloadAllowed;

  Song({
    required this.id,
    required this.title,
    required this.artist,
    required this.audioUrl,
    required this.coverUrl,
    required this.downloadUrl,
    required this.downloadAllowed,
    required this.license,
  });

  factory Song.fromJson(Map<String, dynamic> j) => Song(
    id: j['id'] ?? '',
    title: j['title'] ?? 'Unknown',
    artist: j['artist'] ?? 'Unknown artist',
    audioUrl: j['audioUrl'] ?? '',
    coverUrl: j['coverUrl'] ?? '',
    downloadUrl: j['downloadUrl'] ?? '',
    downloadAllowed: j['downloadAllowed'] == true,
    license: j['license'] ?? '',
  );
}

class MusicHandler extends BaseAudioHandler with SeekHandler {
  final AudioPlayer player = AudioPlayer();

  MusicHandler() {
    player.playbackEventStream.listen((event) {
      playbackState.add(PlaybackState(
        controls: [
          if (player.playing) MediaControl.pause else MediaControl.play,
          MediaControl.stop,
        ],
        androidCompactActionIndices: const [0, 1],
        playing: player.playing,
        processingState: _state(player.processingState),
        updatePosition: player.position,
        bufferedPosition: player.bufferedPosition,
        speed: player.speed,
      ));
    });
    player.positionStream.listen((_) => _emitState());
  }

  AudioProcessingState _state(ProcessingState s) {
    switch (s) {
      case ProcessingState.idle: return AudioProcessingState.idle;
      case ProcessingState.loading: return AudioProcessingState.loading;
      case ProcessingState.buffering: return AudioProcessingState.buffering;
      case ProcessingState.ready: return AudioProcessingState.ready;
      case ProcessingState.completed: return AudioProcessingState.completed;
    }
  }

  void _emitState() {
    playbackState.add(playbackState.value.copyWith(
      updatePosition: player.position,
      playing: player.playing,
    ));
  }

  Future<void> setSource(String pathOrUrl, {String? title, String? artist}) async {
    await player.setAudioSource(
      pathOrUrl.startsWith('http')
        ? AudioSource.uri(Uri.parse(pathOrUrl))
        : AudioSource.file(pathOrUrl),
    );
    mediaItem.add(MediaItem(
      id: pathOrUrl,
      title: title ?? 'Surivo Music',
      artist: artist ?? '',
      duration: player.duration,
    ));
  }

  @override Future<void> play() => player.play();
  @override Future<void> pause() => player.pause();
  @override Future<void> stop() => player.stop();
  @override Future<void> seek(Duration position) => player.seek(position);
}

late MusicHandler musicHandler;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  musicHandler = await AudioService.init(
    builder: () => MusicHandler(),
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'com.surivo.music.channel',
      androidNotificationChannelName: 'Surivo Music',
      androidNotificationOngoing: true,
    ),
  );
  runApp(const SurivoApp());
}

class SurivoApp extends StatelessWidget {
  const SurivoApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Surivo Music',
    theme: ThemeData.dark(useMaterial3: true),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Song> songs = [];
  Set<String> favorites = {};
  Set<String> downloaded = {};
  String query = '';
  Song? current;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    favorites = (prefs.getStringList('favorites') ?? []).toSet();
    downloaded = (prefs.getStringList('downloaded') ?? []).toSet();

    final raw = await DefaultAssetBundle.of(context).loadString('assets/catalog.json');
    songs = (jsonDecode(raw) as List).map((e) => Song.fromJson(e)).toList();
    setState(() => loading = false);
  }

  Future<Directory> _downloadDir() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/SurivoMusic');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<void> _play(Song s) async {
    final dir = await _downloadDir();
    final file = File('${dir.path}/${s.id}.mp3');
    if (await file.exists()) {
      await musicHandler.setSource(file.path, title: s.title, artist: s.artist);
    } else {
      if (s.audioUrl.isEmpty) return;
      await musicHandler.setSource(s.audioUrl, title: s.title, artist: s.artist);
    }
    await musicHandler.play();
    setState(() => current = s);
  }

  Future<void> _download(Song s) async {
    if (!s.downloadAllowed || s.downloadUrl.isEmpty) {
      _msg('This song is not marked as downloadable by its source.');
      return;
    }
    try {
      _msg('Downloading...');
      final r = await http.get(Uri.parse(s.downloadUrl));
      if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}');
      final dir = await _downloadDir();
      final file = File('${dir.path}/${s.id}.mp3');
      await file.writeAsBytes(r.bodyBytes);
      downloaded.add(s.id);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList('downloaded', downloaded.toList());
      setState(() {});
      _msg('Downloaded for offline playback.');
    } catch (e) {
      _msg('Download failed: $e');
    }
  }

  Future<void> _addLocalFile() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (result == null || result.files.single.path == null) return;
    final src = File(result.files.single.path!);
    final dir = await _downloadDir();
    final name = result.files.single.name.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
    await src.copy('${dir.path}/$name');
    _msg('Added to offline library.');
  }

  Future<void> _toggleFav(Song s) async {
    final prefs = await SharedPreferences.getInstance();
    if (favorites.contains(s.id)) {
      favorites.remove(s.id);
    } else {
      favorites.add(s.id);
    }
    await prefs.setStringList('favorites', favorites.toList());
    setState(() {});
  }

  void _msg(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  List<Song> get filtered => songs.where((s) =>
    s.title.toLowerCase().contains(query.toLowerCase()) ||
    s.artist.toLowerCase().contains(query.toLowerCase())
  ).toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Surivo Music'),
        actions: [
          IconButton(onPressed: _addLocalFile, icon: const Icon(Icons.library_music)),
        ],
      ),
      body: loading
        ? const Center(child: CircularProgressIndicator())
        : Column(children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                decoration: const InputDecoration(
                  hintText: 'Search songs...',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onChanged: (v) => setState(() => query = v),
              ),
            ),
            Expanded(
              child: filtered.isEmpty
                ? const Center(child: Text('No online songs in the catalog yet.'))
                : ListView.builder(
                    itemCount: filtered.length,
                    itemBuilder: (_, i) {
                      final s = filtered[i];
                      return ListTile(
                        leading: const CircleAvatar(child: Icon(Icons.music_note)),
                        title: Text(s.title),
                        subtitle: Text(s.artist),
                        onTap: () => _play(s),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              onPressed: () => _toggleFav(s),
                              icon: Icon(favorites.contains(s.id)
                                ? Icons.favorite : Icons.favorite_border),
                            ),
                            if (downloaded.contains(s.id))
                              const Icon(Icons.download_done)
                            else
                              IconButton(
                                onPressed: s.downloadAllowed ? () => _download(s) : null,
                                icon: const Icon(Icons.download),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
            ),
            if (current != null) _PlayerBar(song: current!),
          ]),
    );
  }
}

class _PlayerBar extends StatelessWidget {
  final Song song;
  const _PlayerBar({required this.song});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(children: [
        const Icon(Icons.music_note),
        const SizedBox(width: 10),
        Expanded(child: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
        StreamBuilder<bool>(
          stream: musicHandler.player.playingStream,
          builder: (_, snap) => IconButton(
            icon: Icon(snap.data == true ? Icons.pause : Icons.play_arrow),
            onPressed: () => snap.data == true ? musicHandler.pause() : musicHandler.play(),
          ),
        ),
      ]),
    );
  }
}
